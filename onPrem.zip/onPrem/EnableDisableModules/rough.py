list_of_modules = ["<hypodensitystandalone>", "<hypodensitywithctp>", "<enablehyperdensity>", "<enablehvs>", "<enablectpa>", "<enableich>", "<enableaspects>", "<enableNcctArtifactDetection>", "<enablencctstroke>", "<enableneuro3d>", "<enableanrtn>", "<enablepetn>", "<enablervlv>", "<enablecta>", "<enablemismatch>", "<enablesdh>"]

print(list_of_modules.pop())

print(list_of_modules)

print(list_of_modules.pop())

print(list_of_modules)