#!/bin/bash

python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Automation/fetchTaskIDWorkflowID/fetchTaskIDWorkflowID_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Automation/global.json