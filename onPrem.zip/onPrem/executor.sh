#!/bin/bash

#python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Automation_6_2/EnableDisableModules/enableModules_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Automation_6_2/global.json && python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Automation_6_2/UploadDatasetParallel/upload_dataset_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Automation_6_2/global.json && python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Automation_6_2/fetchTaskIDWorkflowID/fetchTaskIDWorkflowID_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Automation_6_2/global.json

#python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/UploadDatasetParallel/upload_dataset_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/global.json && python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/fetchTaskIDWorkflowID/fetchTaskIDWorkflowID_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/global.json

#/usr/local/bin/python3.12 /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/UploadDatasetParallel/upload_dataset_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/global.json
python3 /Users/zinnov/Documents/Auto_modules_6_2/onPrem/UploadDatasetParallel/upload_dataset_main.py /Users/zinnov/Documents/Auto_modules_6_2/onPrem/global.json

#python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/fetchTaskIDWorkflowID/fetchTaskIDWorkflowID_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/global.json



# Ritesh's script

#python3 /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/UploadDatasetParallel/upload_dataset_main.py /Users/subhrasis/Documents/Rapid_pythonScripts/Auto_modules_6_2/onPrem/ritesh_build.json
